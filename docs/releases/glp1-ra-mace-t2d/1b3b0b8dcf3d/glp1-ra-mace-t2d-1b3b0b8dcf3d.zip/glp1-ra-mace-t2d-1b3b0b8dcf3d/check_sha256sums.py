#!/usr/bin/env python3
"""Check SHA256SUMS in this directory (for machines without sha256sum). Exit 0 iff every line matches."""
import hashlib, sys
from pathlib import Path
here = Path(__file__).resolve().parent
bad = n = 0
for line in (here / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
    digest, name = line.split("  ", 1)
    p = here / name
    ok = p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == digest
    n += 1
    bad += not ok
    if not ok:
        print("FAILED", name)
print(f"{n - bad} of {n} files match SHA256SUMS")
sys.exit(1 if bad else 0)
