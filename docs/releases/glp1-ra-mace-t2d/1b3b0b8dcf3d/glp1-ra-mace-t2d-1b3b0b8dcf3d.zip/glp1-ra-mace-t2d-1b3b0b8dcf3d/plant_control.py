#!/usr/bin/env python3
"""Control that must FAIL: copy site/ to a temporary directory, change ONE served value (the primary pooled estimate in
review.json, x1.01 -- a value change, not whitespace), and run the archived verifier on the copy. Then run it on the
untouched site/. Exit 0 iff the damaged copy does NOT pass and the untouched site does. Standard library only."""
import json, shutil, subprocess, sys, tempfile
from pathlib import Path
here = Path(__file__).resolve().parent
slug = json.loads((here / "RELEASE.json").read_text(encoding="utf-8"))["slug"]
verifier = here / "site" / "scripts" / "verify_bundle.py"
def verdict(root):
    p = subprocess.run([sys.executable, str(verifier), "--root", str(root), "--slug", slug], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", stdin=subprocess.DEVNULL)
    return next((l for l in p.stdout.splitlines() if "verdict" in l), "no verdict line").strip()
with tempfile.TemporaryDirectory() as tmp:
    copy = Path(tmp) / "site"
    shutil.copytree(here / "site", copy)
    rv = copy / "reviews" / slug / "review.json"
    doc = json.loads(rv.read_text(encoding="utf-8"))
    prim = next(o for o in doc["outcomes"] if o.get("primary"))
    before = prim["result"]["estimate"]
    prim["result"]["estimate"] = before * 1.01
    rv.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    damaged = verdict(copy)
clean = verdict(here / "site")
print(f"damaged copy (primary estimate {before} -> {before * 1.01}): {damaged}")
print(f"untouched site: {clean}")
fired = "verdict PASS" not in damaged and "verdict PASS" in clean
print("CONTROL FIRED" if fired else "CONTROL DID NOT FIRE -- do not trust a PASS from this verifier")
sys.exit(0 if fired else 1)
