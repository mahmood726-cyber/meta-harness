from pathlib import Path

p = Path(r"C:/mh-lanes/nr/wt/scripts/notice_anchor.py")
b = p.read_bytes()
b = b.replace(bytes([0]), b"\\" + b"0")
p.write_bytes(b)
print(b.count(bytes([0])), b[b.find(b"blob %d") - 5:b.find(b"blob %d") + 20])
