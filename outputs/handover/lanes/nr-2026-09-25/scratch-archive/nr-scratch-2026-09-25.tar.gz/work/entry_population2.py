"""ENTRY_POPULATION_NOT_ESTABLISHED departures: re-run the exact P5 test on the held conditions (full payload)."""
import gzip
import json
import subprocess
import sys
from pathlib import Path

W = Path(r"C:/mh-lanes/nr/wt")
sys.path.insert(0, str(W))
from harness import trial_family  # noqa: E402

REV = "1fa77f2c4852ee79e55d540083e3c35bbff0cecc"
rows = json.loads(Path(r"C:/mh-lanes/nr/work/departing_evidence.json").read_text(encoding="utf-8"))


def show(path):
    p = subprocess.run(["git", "show", f"{REV}:{path}"], cwd=W, capture_output=True)
    return p.stdout if p.returncode == 0 else None


def find_family(node, fid):
    if isinstance(node, dict):
        if node.get("family_id") == fid and "population" in node:
            return node
        for v in node.values():
            hit = find_family(v, fid)
            if hit:
                return hit
    elif isinstance(node, list):
        for v in node:
            hit = find_family(v, fid)
            if hit:
                return hit
    return None


payloads, seen, out = {}, set(), []
for r in rows:
    if r["code"] != "ENTRY_POPULATION_NOT_ESTABLISHED" or (r["slug"], r["family"]) in seen:
        continue
    seen.add((r["slug"], r["family"]))
    if r["slug"] not in payloads:
        raw = show(f"cache/{r['slug']}/family_registry.payload.json.gz")
        payloads[r["slug"]] = json.loads(gzip.decompress(raw)) if raw else {}
    fam = find_family(payloads[r["slug"]], r["family"]) or {}
    cond = ((fam.get("population") or {}).get("conditions") or {}).get("value")
    topic = json.loads(show(f"topics/{r['slug']}.json") or b"{}")
    req = trial_family.protocol_requirements(str(W), r["slug"], dict(topic))
    terms = ((req or {}).get("include") or {}).get("population_any") or []
    text = " ".join(cond or []).lower() if isinstance(cond, list) else str(cond or "").lower()
    passes = any(t.lower() in text for t in terms)
    out.append({"audit_id": r["audit_id"], "slug": r["slug"], "family": r["family"], "conditions": cond,
                "terms_sample": terms[:4], "p5_substring_test_passes_now": passes})
    print(f"{r['audit_id']} {r['family']} | conditions={cond} | terms={terms[:3]}... | substring test passes: {passes}")
Path(r"C:/mh-lanes/nr/work/entry_population.json").write_bytes(json.dumps(out, ensure_ascii=False, indent=1).encode())
