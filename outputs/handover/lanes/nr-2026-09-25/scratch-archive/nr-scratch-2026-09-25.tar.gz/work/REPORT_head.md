# Lane NR: decision B on the 41 result-change notices. Report, 2026-09-25

**Nothing was signed. No lane may sign these.** They change served numbers. The delegated bulk acceptance of
2026-09-24 covers AI screening proposals only, so it does not cover them. The signing list for Mahmood is at the
end.

Branch `nr/notice-anchors` on github.com/mahmood726-cyber/meta-harness. It is cut from `enforcement-gate`
`1fa77f2c`, the only place the 41 notices exist, and nothing was pushed to `main` or `enforcement-gate`.

| commit | what |
|---|---|
| `06ce21d5` | Decision B implemented. All 41 re-judged (judgement B1). Evidence bundle. 66 of 66 targeted tests. |
| `3d0b8b16` | The walker also prints the lane's notes and the bulk reader's concerns above the signing command. |
| `0693f60f` | First signing list and report. |
| `e36f4c33` | **Judgement B2:** the constraint that actually failed admission for every departing trial. 66 of 66 tests. |
| (this commit) | Signing list and report regenerated on B2, under `outputs/handover/lanes/nr-2026-09-25/`. |

**How the landing was proven, from fetched bytes and not from the push.** Each landing was checked in a fresh
clone of the pushed branch (`C:\mh-lanes\nr\land`, removed afterwards to spare the disk):
- At `06ce21d5`, 9 of 9 changed files were byte-identical to the local commit. The walker presented N37 with 9
  of 9 anchors verified, and 66 of 66 tests passed.
- At `0693f60f`, 66 of 66 passed and the regenerated signing list was identical apart from the HEAD sha it names.
- The final tip is proven the same way; see "Final landing proof" at the end.

## 1. What decision B is, as implemented
Decision B was taken by Dispatch under Mahmood's delegation on 24 Sep. Before today it was recorded nowhere in the
repository; it is now in `outputs/handover/lanes/NR_DECISIONS.md` (decisions E1 to E13).

- **Every anchor names the version judged.** An anchor is `git:<commit>:<path>` plus its blob id and sha256. A
  working-tree anchor is refused.
- **A rebuild no longer detaches a notice**, because pinned bytes cannot change.
- **DETACHED is a refusal and stays one.** It means a pinned anchor cannot be verified: the commit or path is absent
  from the clone, or the blob or sha256 is not the one recorded.
- **The guard is still strict.** The walker and `sign` also refuse a notice as **STALE** when the tree presenting
  it no longer serves what was judged. That covers four cases:
  - the result tuple differs from the notice's `after`;
  - the pooled membership differs;
  - the rendered block renders a different signing digest;
  - `index.html` no longer carries the exact rendered block.
  Churn elsewhere on a rebuilt page is disclosed on the walk, not refused. `--expect-digest` is unchanged.
- **For an audited notice, `sign` is stricter than before.** It now requires both `--expect-digest` and
  `--judgement`, refuses DETACHED and STALE, and records `judgement_id` in the signature.
- **No re-pointing without re-judgement.** Judgements are appended, never edited. `notice_rejudge.py append`
  refuses a verdict that does not name exactly the digests it pins. The pre-B working-tree digests are kept as
  history under `superseded_anchors`.
- **Nothing touches `harness/`.** Every harness blob is in the certificates' code closure, so an edit there would
  re-certify all 32 pages. The work lives in `scripts/notice_anchor.py`, `notice_rejudge.py` and
  `notice_signing_list.py`, with edits to `sign_walk.py` and `countersign_result_change.py`.

**Observed on the pre-B walker first** (`observe_first.txt`):
- A churn-only page rebuild made the old walker REFUSE: the rebuild detached the notice.
- The old recovery is to refresh the working-tree digest. After the served number moved from 0.85 to 0.84, that
  let N28 present **with a signing command**.
- The B walker presents the first case with a disclosure and refuses the second as STALE.

## 2. The re-judgement (B1, 41 of 41)
Each judgement pins two versions:
- the **served** page, `origin/main` `c9d665e0`, which is what readers get and which still shows every `before`;
- the page **carrying the notice**, `enforcement-gate` `1fa77f2c`.
Each also pins the three renderer sources, the ledger and, for N37, the held cache record.

- **Mechanical checks: 41 of 41 pass all 13.**
  - `before` equals what main serves today, rechecked against the newer main of 10:00 with no served page changed
    since. It also equals the 38c04411 history.
  - `after` equals the page that carries the notice.
  - `left_pool` and `entered_pool` equal the pooled-set differences exactly.
  - Every departing trial is still named with its P5 reason, and the audit's departing records resolve.
  - The exact block is in the page.
  - Direction, recomputed independently, agrees 41 of 41.
- **Codex bulk comparison: GPT-6, call NR-C01.** It ran read-only with LANE_CONTEXT.md, stdin `/dev/null`, and was
  logged; it used 52,355 tokens.
  - There were 0 disagreements with the mechanical checks across 205 facts.
  - It returned DIFFERS on 4 notices, for rendered wording only.
  - It raised 47 concerns, all carried into the walk.
- **The lane read every notice hostilely: 33 HOLDS, 8 HOLDS_WITH_DEFECT, 0 DIFFERS.** A defect is printed above the
  signing command. It is never a recommendation to sign.
  - **N30, N32, N39** say "Conclusion withdrawn: the outcome no longer has a pooled estimate". The served page had
    **no** pooled estimate before: k = 2 was refused as DIRECTION_CONFLICT_K2, confirmed on served main.
  - **N06, N27**: the notice is the **only** place on its page showing a harm number (RR 3.74, and RR 1.23 with
    0.98 to 1.54) that the outcome section deliberately withholds (HARMS_INCOMPLETE). N27's number also appears
    with no membership change and no stated cause; its "why" is the generic P5 sentence.
  - **N28, N38** create a **new** claim of a difference, a CI excluding 1 where no interval was served. They render
    "The direction of the estimate is unchanged" with no "Conclusion changed" sentence, whereas N20 says so for the
    same kind of change.
  - **N17** renders "direction unchanged" for HR 1.007 → exactly 1.00.
- **One codex concern was refuted.** For N30 it said DIRECTION_CONFLICT_K2 was not established. The served page
  states it, in the earlier signed notice at chain index 9 → 42.
- **Hostile notes Mahmood should read before signing**, all shown on the walk:
  - **N37**: RALES (1999, RR 0.70, 0.60 to 0.82) leaves on REGISTRY_PARENT_UNRESOLVED because it predates
    registries. EMPHASIS-HF leaves as INELIGIBLE with a conflicting registry record. The mortality benefit is then
    withdrawn on **one** remaining trial whose endpoint is unbound (legacy). D01 is related and still pending.
  - **N25**: all 4 NOAC trials leave on INTERVENTION_CONTRAST_NOT_PROVEN, so NOAC vs warfarin for stroke then has
    **no** pooled estimate. The audit groups it for batch treatment (G1); the lane recommends reading it
    individually.
  - **N29**: 11 of 11 probiotics trials leave.
  - **N13**: 6 of 6 DOAC trials leave.
  - **N20**: a new significant benefit from one trial.
  - **N23**: a new HR 0.39 from one trial.

## 2b. Judgement B2: why each trial actually left. This is the finding Mahmood most needs before signing.
Every notice's "why" says a departing trial's family eligibility is "not established by the held record". I tested
that sentence against the held rows for **all 78 departing memberships**, using the check's own source
(`harness/trial_family.py`) and the page's `trial_families` nodes at `1fa77f2c`:

| What actually failed | memberships |
|---|---|
| **The check misreads rows the site already holds** | **34** |
| • ACTIVE_COMPARATOR: `randomised_contrasts` records a contrast only when two arms differ by the agent alone, so a drug-vs-active-drug trial **can never pass**. This covers all 4 NOAC-vs-warfarin trials (RE-LY, ROCKET AF, ARISTOTLE, ENGAGE), PLATO, PARADIGM-HF and the DOAC-vs-VKA trials. | 16 |
| • TERM_FORM_MISMATCH: 'Diabetes Mellitus, Type 2' misses 'type 2 diabetes'; 'Depressive Disorder, Treatment-Resistant' misses 'treatment-resistant depression'; HFpEF worded as 'preserved systolic function' | 10 |
| • WILDCARD_NOT_HONOURED: the protocol term `antibiotic-associated diarr*` is tested as a literal substring | 2 |
| • CONTROL_CODED_AS_ACTIVE: saline, corn oil or placebo is registered as an active intervention | 4 |
| • LEXICON_GAP: omarigliptin and AMR101 are not in the topic's agent list | 2 |
| The check cannot read the source: 20 have no registry parent linked; 5 are ACTRN or ISRCTN trials, and the check reads ClinicalTrials.gov rows only | 25 |
| The rows genuinely do not establish the population or contrast | 18 |
| INELIGIBLE on held rows (EMPHASIS-HF, with the recorded registry conflict) | 1 |

**How the classification was checked**
- My labels were written down before a blind second read (sha256 346c8d4b…).
- The codex call for that read (NR-C02) hit the seat's usage limit (until 26 Sep 18:09) and was logged with
  rc=1. The second read therefore came from a Claude subagent. That is the same model family, so it is weaker.
  It agreed on 70 of 78 labels and 75 of 78 buckets.
- I executed seven cases on `screen_family` with only the blamed field changed. DELIVER, CARMELINA, TRANSFORM, a
  probiotics trial, ROCKET AF, PLATO and PARADIGM-HF each went from UNKNOWN to **ELIGIBLE**. A control that
  re-derives the contrasts and changes nothing stays NOT_PROVEN (`b2-binding/screen_plants.txt`).

**What it means for signing.** For 12 notices, both readers say every departure is a misread of held rows: **N08,
N09, N15, N17, N18, N19, N20, N21, N25, N32, N39, N40**. The lane's label alone adds N23. N20's newly significant
esketamine benefit exists only because a word-order mismatch removed two trials. N25's "no pooled estimate for
NOAC vs warfarin" exists because the check cannot represent an active comparator.

Each notice records accurately what the gate did. Countersigning these would ratify served-number changes that
the check produced. **Lane recommendation, not a decision:** fix the check first. That is a `harness/` change, so it
means a re-certification and new notices generated from the real transitions. Then sign what remains. The walker
prints each trial's binding constraint, with its evidence, above the signing command.

## 3. Corrections and findings, including against my own work
- **The brief's anchor counts.** It said 51 broken and 27 pinned. Measured today against served main `c9d665e0`,
  53 are broken (26 review.json, 24 index.html, 3 harness sources) and 25 are intact (24 `git:38c04411:` plus one
  cache record). All 78 are intact at `1fa77f2c`.
- **The committed audit's `notice_block_sha256` is stale.** It reproduces 0 of 41, across eleven derivations at
  four commits, and nothing reads it. The judgements record the digest `sign --expect-digest` actually checks. The
  F4 lane's unpushed registry recomputed the same 41 digests independently, and all 41 are equal.
- **My own first design was wrong, and was fixed before landing (E11).** It compared anchors with the working tree
  byte for byte. That made every rebuild detach every notice again, which is the defect B exists to remove. The F4
  lane's handover, read as data, stated the intent plainly.
- **My codex runner's logger crashed silently.** It hit a SyntaxError while the runner still printed `rc=0`, the
  same failure as an exit code read through a pipe. NR-C01 was logged post hoc from its artefacts and is marked as
  such. The logger is now a separate file, followed by a check that the log line exists; the runner exits 4 or 5
  otherwise.
- **The F4 lane.** At 08:20 it dropped a handover and its artefacts into this lane's directory, saying it had
  already done B. It is unpushed and held locally. The two agree:
  - both pinned `1fa77f2c`;
  - their signing digests are equal, 41 of 41;
  - both independently escalated N27, N28 and N38.
  This branch adds:
  - the served-main pin and its check (41 of 41);
  - the codex bulk reader;
  - append-only judgements with each verdict bound to its digests;
  - five wording defects F4 did not report.
  F4's patch was not landed. The branch carries one implementation (E12).

## 4. Not done, and risks
- **`verify_all` was not run.** The branch is red by design (3 of 11 limbs, as its parent recorded), the sparse
  clone omits the 1.3 GB `cache/` on a disk that fell below 0.5 GB free, and the lane was told to stay CPU-light.
  No hook was bypassed: `hooksPath` is unset in these clones, and the commit-msg hook was run by hand and passed.
- **The gate's `after` values were not re-derived on today's main**, which would need a full rebuild. Main changed
  no admission input since `38c04411`: no `cache/`, `topics/` or `protocols/` diff, and the `harness/` diff is
  extract.py R1+R4 (documented as byte-identical extraction), the page-verifier block and
  DELEGATED_IS_NOT_A_SIGNATURE. So they are not expected to move. If they do, the notices go STALE; they are not
  signed wrongly.
- **Merging main into `enforcement-gate` will not detach the 41.** A merge that moves a served number will make
  that notice STALE, by design. The recovery is `notice_rejudge.py packets`, then a review, then `append`, never a
  digest edit.
- **Evid-lane interaction.** The evid lane produces eligibility evidence; its latest commit confirms LoDoCo2
  non-CV death. LoDoCo2 is N05's departing trial. If eligibility evidence restores a departing trial before
  signing, that notice goes STALE after the rebuild, correctly.
- **Direction orientation is a hardcoded list.** `HIGHER_IS_FAVOURABLE` holds one (slug, outcome) pair, ovulation.
  A new higher-is-better outcome would be read as lower-is-better. F4 flagged the same latent issue in its
  heuristic. It is correct on 41 of 41 today, and codex classified direction independently and agreed.
- **The ledger generator's defects remain.** It stamps a generic mechanism sentence (N27) and the wording defects
  above come from it. Fixing it means `harness/`: a re-certification and new notices, which is its own landing.
- **Coordination.** Messaging the main-lane session was not available in this session, so coordination is on the
  branch (NR_DECISIONS.md). The main lane's branch has not moved since 24 Sep 08:01.
- **Codex calls, 3 in total, logged in `nr-2026-09-25/CALL_LOG.jsonl`:** NR-C00 was the liveness probe ("OK,
  GPT-6"), NR-C01 was the bulk comparison, and NR-C02 hit the usage limit (rc=1, no answer used). The seat is
  exhausted until 26 Sep 18:09.

## 5. How Mahmood signs, when he chooses to
From a clone of `nr/notice-anchors`, in PowerShell at the repository root:
`python scripts/sign_walk.py --notice NXX`. It presents one notice and stops. It prints:
- the judgement and its drift disclosure;
- any defect, the lane's note and codex's concerns;
- the rendered block and its sha256;
- the exact command, which carries `--notice-index`, `--expect-digest`, `--judgement` and a `Read-Host` prompt for
  his own `--basis`.
Nothing he runs is pre-filled with his account.

## Signing list for Mahmood (41 OPEN; in the walker's fixed order; nothing signed)
Each row gives the one-line before → after as judged and the rendered-block sha256, which is what
`sign --expect-digest` checks and what his signature will name. It also gives how_it_reached_the_reviewer, meaning
how the notice is queued to reach him. When he signs, `--basis` records his own account of what he read.
