import json
from pathlib import Path

B = Path(r"C:/mh-lanes/nr/wt/outputs/handover/lanes/nr-2026-09-25")
rows = json.loads((B / "signing_list.json").read_text(encoding="utf-8"))["rows"]
codex = json.loads((B / "codex-NR-C01/last_message.txt").read_text(encoding="utf-8"))["verdicts"]
n_concerns = sum(len(v["concerns"]) for v in codex)
n_facts = 5 * len(codex)
head = Path(r"C:/mh-lanes/nr/work/REPORT_head.md").read_text(encoding="utf-8")
assert "47 concerns" in head and "205 facts" in head
head = head.replace("47 concerns", f"{n_concerns} concerns").replace("205 facts", f"{n_facts} facts")
out = [head]
for r in rows:
    flag = f" **{r['lane_verdict']}**" if r["lane_verdict"] != "HOLDS" else ""
    out.append(
        f"{r['position']}. **{r['audit_id']}**: {r['slug']} / {r['outcome']} (ledger index {r['ledger_index']}; "
        f"{'individual signature' if r['gate_requires_individual_signature'] else 'batch-eligible'}; audit: "
        f"{r['audit_recommendation']}; judgement {r['judgement_id']}{flag})\n"
        f"   - before → after: {r['before_after']}\n"
        f"   - hash (rendered block sha256): `{r['rendered_block_sha256']}`\n"
        f"   - departures the admission check misread (lane, B2): {r['departures_misread_by_check']} of {r['departures']}"
        + (" -- EVERY departure; the lane recommends fixing the check before signing\n"
           if r['departures'] and r['departures_misread_by_check'] == r['departures'] else "\n")
        + f"   - how_it_reached_the_reviewer: {r['how_it_reached_the_reviewer']}\n"
        + "".join(f"   - DEFECT (lane): {d}\n" for d in r["defects"]))
text = "\n".join(out) + (
    "\nNot on this list: D01 (J-EMPHASIS-HF) is NOT SIGNABLE. The RR correction has not been made, so there is no "
    "notice to sign; Mahmood rules first.\n")
for dest in (Path(r"C:/mh-lanes/nr/REPORT_2026-09-25.md"), B / "REPORT_2026-09-25.md"):
    dest.write_bytes(text.encode("utf-8"))
print(n_concerns, n_facts, len(rows), sum(r["lane_verdict"] != "HOLDS" for r in rows))
