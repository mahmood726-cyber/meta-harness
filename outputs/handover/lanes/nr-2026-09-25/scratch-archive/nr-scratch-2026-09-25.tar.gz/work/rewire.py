from pathlib import Path

W = Path(r"C:/mh-lanes/nr/wt")

p = W / "scripts/sign_walk.py"
s = p.read_text(encoding="utf-8")
old = '''    # Every anchor of every current judgement: pinned bytes exact, live sides carried by this tree. A DETACHED
    # anchor refuses the whole walk -- a refusal on a detached anchor stays a refusal, and nothing re-points it.
    for row in audit["notices"]:
        notice_anchor.verify_row(ROOT, row)
'''
new = '''    # Decision B, for every audited notice: each pinned anchor verifies (else DETACHED), and this tree still serves
    # what was judged -- the after tuple, the pooled membership, the signing digest and the rendered block in the
    # page (else STALE). Either refuses the whole walk; only an appended re-judgement clears it, never a digest edit.
    for row in audit["notices"]:
        notice = notices[mapping[row["audit_id"]]]
        _, block, sha = countersign._block_and_sha(notice)
        notice_anchor.guard(ROOT, row, notice, block, sha)
'''
assert old in s
s = s.replace(old, new)
old = '''    judgement = notice_anchor.current_judgement(row)
    if sha != judgement["rendered_block_sha256"]:
        raise ValueError(f"{row['audit_id']}: the notice now renders sha256 {sha}, judgement "
                         f"{judgement['judgement_id']} judged {judgement['rendered_block_sha256']}; re-judgement required")
'''
new = '''    judgement, drifted = notice_anchor.guard(ROOT, row, notice, block, sha)
'''
assert old in s
s = s.replace(old, new)
old = '''             "commit-pinned anchors verified and attached. Before -> after as judged: " + judgement["before_after"],'''
new = '''             "commit-pinned anchors verified; this tree still serves the judged after, pooled membership and "
             "rendered block. Before -> after as judged: " + judgement["before_after"],
             ("Rebuilt since judgement (disclosed; the checks above still hold): " + "; ".join(drifted)) if drifted
             else "No judged file differs in this tree.",'''
assert old in s
s = s.replace(old, new)
p.write_bytes(s.encode("utf-8"))

p = W / "scripts/countersign_result_change.py"
s = p.read_text(encoding="utf-8")
old = '''        try:
            judgement = notice_anchor.verify_row(ROOT, row)
        except notice_anchor.AnchorRefused as error:
            sys.exit(f"refused: {error}; nothing written")
        if args.judgement != judgement["judgement_id"]:
            sys.exit(f"refused: --judgement {args.judgement} is not this notice's current judgement "
                     f"{judgement['judgement_id']}; nothing written")
        if judgement["rendered_block_sha256"] != sha:
            sys.exit(f"refused: judgement {judgement['judgement_id']} judged rendering {judgement['rendered_block_sha256']}, "
                     f"this tree renders {sha}; re-judgement required; nothing written")
'''
new = '''        try:
            judgement, _ = notice_anchor.guard(ROOT, row, n, block, sha)
        except notice_anchor.AnchorRefused as error:
            sys.exit(f"refused: {error}; nothing written")
        if args.judgement != judgement["judgement_id"]:
            sys.exit(f"refused: --judgement {args.judgement} is not this notice's current judgement "
                     f"{judgement['judgement_id']}; nothing written")
'''
assert old in s
s = s.replace(old, new)
s = s.replace('''judgement: `sign` then REQUIRES --expect-digest and --judgement, refuses if any anchor of that judgement is DETACHED
from this tree or the judged rendering differs, and records the judgement_id in the signature, so the signature names
the version that was judged as well as the bytes that were read.''', '''judgement: `sign` then REQUIRES --expect-digest and --judgement, refuses if any anchor of that judgement is DETACHED
(unverifiable) or the notice is STALE (this tree no longer serves the judged after, membership, rendering or page
block; scripts/notice_anchor.guard), and records the judgement_id in the signature, so the signature names the
version that was judged as well as the bytes that were read.''')
p.write_bytes(s.encode("utf-8"))
print("ok")
