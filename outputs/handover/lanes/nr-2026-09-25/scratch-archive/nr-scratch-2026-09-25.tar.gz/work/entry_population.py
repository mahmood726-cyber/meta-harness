"""For each ENTRY_POPULATION_NOT_ESTABLISHED departure: the protocol's population_any terms beside the held
registry conditions text the P5 check actually searched (harness/trial_family.py, substring test). Read-only."""
import json
import subprocess
import sys
from pathlib import Path

W = Path(r"C:/mh-lanes/nr/wt")
sys.path.insert(0, str(W))
from harness import trial_family  # noqa: E402

REV = "1fa77f2c4852ee79e55d540083e3c35bbff0cecc"
rows = json.loads(Path(r"C:/mh-lanes/nr/work/departing_evidence.json").read_text(encoding="utf-8"))


def show(path):
    p = subprocess.run(["git", "show", f"{REV}:{path}"], cwd=W, capture_output=True)
    return p.stdout if p.returncode == 0 else None


seen = set()
for r in rows:
    if r["code"] != "ENTRY_POPULATION_NOT_ESTABLISHED" or (r["slug"], r["family"]) in seen:
        continue
    seen.add((r["slug"], r["family"]))
    topic = json.loads(show(f"topics/{r['slug']}.json") or b"{}")
    try:
        req = trial_family.protocol_requirements(str(W), r["slug"], dict(topic))
    except Exception as e:  # noqa: BLE001
        req = {"error": repr(e)}
    inc = (req or {}).get("include") or {}
    fam = next((f for f in json.loads(show(f"cache/{r['slug']}/families.json"))["families"]
                if f["family_id"] == r["family"]), {})
    cond = ((fam.get("population") or {}).get("conditions") or {}).get("value")
    print(f"{r['audit_id']} {r['family']} | population_any={inc.get('population_any')} | held conditions={cond}")
