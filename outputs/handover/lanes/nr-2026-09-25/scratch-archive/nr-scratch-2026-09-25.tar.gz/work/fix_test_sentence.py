from pathlib import Path

old = ("**0 new failures.** All 14 are the same missing-file errors the sparse clone causes on the original "
       "(`cache/`, `docs/*.json` not checked out). The 15th, a live-browser UI test, failed only on the original "
       "run (`p5-fix/tf_tests_*.log`)")
new = ("**0 new failures**: all 14 patched failures also fail on the original. Almost all are missing-file errors "
       "because the sparse clone does not check out `cache/` or `docs/*.json`. One asserts \"control has at least "
       "one ADMISSIBLE row to plant on\", and fails identically on both. The 15th original failure, a live-browser "
       "UI test, failed only on the original run (`p5-fix/tf_tests_*.log`). **Run the full suite on a full "
       "checkout before V1**")
for p in (Path(r"C:/mh-lanes/nr/work/HANDOVER_MAIN_LANE_P5_FIX.md"), Path(r"C:/mh-lanes/nr/HANDOVER_MAIN_LANE_P5_FIX.md"),
          Path(r"C:/mh-lanes/nr/wt/outputs/handover/lanes/nr-2026-09-25/HANDOVER_MAIN_LANE_P5_FIX.md")):
    s = p.read_text(encoding="utf-8")
    assert old in s, p
    p.write_bytes(s.replace(old, new).encode("utf-8"))
print("ok")
