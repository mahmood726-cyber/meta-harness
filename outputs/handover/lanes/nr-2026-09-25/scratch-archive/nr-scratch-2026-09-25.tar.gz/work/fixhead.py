from pathlib import Path

p = Path(r"C:/mh-lanes/nr/work/REPORT_head.md")
s = p.read_text(encoding="utf-8")
s = s.replace("(decisions E1 to E12)", "(decisions E1 to E13)")
start = s.index("**How the landing was proven, from fetched bytes and not from the push:**")
end = s.index("## 1. What decision B is, as implemented")
s = s[:start] + (
    "**How the landing was proven, from fetched bytes and not from the push.** Each landing was checked in a fresh\n"
    "clone of the pushed branch (`C:\\mh-lanes\\nr\\land`, removed afterwards to spare the disk):\n"
    "- At `06ce21d5`, 9 of 9 changed files were byte-identical to the local commit. The walker presented N37 with 9\n"
    "  of 9 anchors verified, and 66 of 66 tests passed.\n"
    "- At `0693f60f`, 66 of 66 passed and the regenerated signing list was identical apart from the HEAD sha it names.\n"
    "- The final tip is proven the same way; see \"Final landing proof\" at the end.\n\n") + s[end:]
p.write_bytes(s.encode("utf-8"))
print("ok", "E1 to E13" in s)
