from pathlib import Path

W = Path(r"C:/mh-lanes/nr/wt")
p = W / "scripts/notice_rejudge.py"
s = p.read_text(encoding="utf-8")
old = '''    if _show(proposed, "registry/notice_adjudication.json") != audit_bytes:
        raise anchor.AnchorRefused("the working registry differs from the proposed commit's; judge committed bytes")'''
new = '''    if _show("HEAD", "registry/notice_adjudication.json") != audit_bytes:
        raise anchor.AnchorRefused("the working registry differs from HEAD's; judge committed bytes (commit first)")'''
assert old in s
s = s.replace(old, new)
old = '''            "defects": v.get("defects", []), "bulk_concerns": v.get("bulk_concerns", []),'''
new = '''            "defects": v.get("defects", []), "bulk_concerns": v.get("bulk_concerns", []),
            "departure_binding": v.get("departure_binding", []), "second_reader": v.get("second_reader"),'''
assert old in s
s = s.replace(old, new)
s = s.replace('''      mechanical check passes. HOLDS_WITH_DEFECT means''', '''      mechanical check passes. The working registry must equal HEAD's (judge committed bytes). A verdict may also
      carry `departure_binding` (per departing trial: the constraint that actually failed the admission check, as
      the lane read it) and `second_reader`. HOLDS_WITH_DEFECT means''')
p.write_bytes(s.encode("utf-8"))

p = W / "scripts/sign_walk.py"
s = p.read_text(encoding="utf-8")
old = '''    for concern in judgement.get("bulk_concerns") or []:'''
new = '''    binding = judgement.get("departure_binding") or []
    if binding:
        misread = sum(b["bucket"] == "CHECK_MISREADS_HELD_ROWS" for b in binding)
        lines.append(f"WHY EACH TRIAL LEFT, as the lane read it ({judgement['judgement_id']}; not Mahmood's decision): "
                     f"{misread} of {len(binding)} departures fail the admission check because of how the check reads "
                     "rows the site already holds, not because the evidence is absent.")
        for b in binding:
            lines.append(f"  {b['trial_id']} ({b['family_id']}): {b['gate_code']} -> {b['class']} [{b['bucket']}]: {b['basis']}")
    for concern in judgement.get("bulk_concerns") or []:'''
assert old in s
s = s.replace(old, new)
p.write_bytes(s.encode("utf-8"))

p = W / "scripts/notice_signing_list.py"
s = p.read_text(encoding="utf-8")
old = '''            "lane_notes": j["lane_notes"],'''
new = '''            "lane_notes": j["lane_notes"],
            "departures_misread_by_check": sum(b["bucket"] == "CHECK_MISREADS_HELD_ROWS"
                                               for b in j.get("departure_binding") or []),
            "departures": len(j.get("departure_binding") or []),'''
assert old in s
s = s.replace(old, new)
s = s.replace('''             "Lane verdict | Signature | Audit recommendation |",
             "|---|---|---|---|---|---|---|---|---|"]''', '''             "Lane verdict | Departures the check misread | Signature | Audit recommendation |",
             "|---|---|---|---|---|---|---|---|---|---|"]''')
s = s.replace('''                     f"{r['lane_verdict']} | {'individual' if''', '''                     f"{r['lane_verdict']} | {r['departures_misread_by_check']} of {r['departures']} | {'individual' if''')
p.write_bytes(s.encode("utf-8"))
print("ok")
