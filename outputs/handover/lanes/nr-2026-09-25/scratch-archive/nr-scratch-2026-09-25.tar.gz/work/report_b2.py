from pathlib import Path

h = Path(r"C:/mh-lanes/nr/work/REPORT_head.md")
s = h.read_text(encoding="utf-8")
old = """| (this commit) | Signing list and this report, under `outputs/handover/lanes/nr-2026-09-25/`. |"""
new = """| `0693f60f` | First signing list and report. |
| `e36f4c33` | **Judgement B2:** the constraint that actually failed admission for every departing trial. 66 of 66 tests. |
| (this commit) | Signing list and report regenerated on B2, under `outputs/handover/lanes/nr-2026-09-25/`. |"""
assert old in s
s = s.replace(old, new)
old = "## 3. Corrections and findings, including against my own work"
new = """## 2b. Judgement B2: why each trial actually left. This is the finding Mahmood most needs before signing.
Every notice's "why" says a departing trial's family eligibility is "not established by the held record". I tested
that sentence against the held rows for **all 78 departing memberships**, using the check's own source
(`harness/trial_family.py`) and the page's `trial_families` nodes at `1fa77f2c`:

| What actually failed | memberships |
|---|---|
| **The check misreads rows the site already holds** | **34** |
| • ACTIVE_COMPARATOR: `randomised_contrasts` records a contrast only when two arms differ by the agent alone, so a drug-vs-active-drug trial **can never pass**. This covers all 4 NOAC-vs-warfarin trials (RE-LY, ROCKET AF, ARISTOTLE, ENGAGE), PLATO, PARADIGM-HF and the DOAC-vs-VKA trials. | 16 |
| • TERM_FORM_MISMATCH: 'Diabetes Mellitus, Type 2' misses 'type 2 diabetes'; 'Depressive Disorder, Treatment-Resistant' misses 'treatment-resistant depression'; HFpEF worded as 'preserved systolic function' | 10 |
| • WILDCARD_NOT_HONOURED: the protocol term `antibiotic-associated diarr*` is tested as a literal substring | 2 |
| • CONTROL_CODED_AS_ACTIVE: saline, corn oil or placebo is registered as an active intervention | 4 |
| • LEXICON_GAP: omarigliptin and AMR101 are not in the topic's agent list | 2 |
| The check cannot read the source: 20 have no registry parent linked; 5 are ACTRN or ISRCTN trials, and the check reads ClinicalTrials.gov rows only | 25 |
| The rows genuinely do not establish the population or contrast | 18 |
| INELIGIBLE on held rows (EMPHASIS-HF, with the recorded registry conflict) | 1 |

**How the classification was checked**
- My labels were written down before a blind second read (sha256 346c8d4b…).
- The codex call for that read (NR-C02) hit the seat's usage limit (until 26 Sep 18:09) and was logged with
  rc=1. The second read therefore came from a Claude subagent. That is the same model family, so it is weaker.
  It agreed on 70 of 78 labels and 75 of 78 buckets.
- I executed seven cases on `screen_family` with only the blamed field changed. DELIVER, CARMELINA, TRANSFORM, a
  probiotics trial, ROCKET AF, PLATO and PARADIGM-HF each went from UNKNOWN to **ELIGIBLE**. A control that
  re-derives the contrasts and changes nothing stays NOT_PROVEN (`b2-binding/screen_plants.txt`).

**What it means for signing.** For 12 notices, both readers say every departure is a misread of held rows: **N08,
N09, N15, N17, N18, N19, N20, N21, N25, N32, N39, N40**. The lane's label alone adds N23. N20's newly significant
esketamine benefit exists only because a word-order mismatch removed two trials. N25's "no pooled estimate for
NOAC vs warfarin" exists because the check cannot represent an active comparator.

Each notice records accurately what the gate did. Countersigning these would ratify served-number changes that
the check produced. **Lane recommendation, not a decision:** fix the check first. That is a `harness/` change, so it
means a re-certification and new notices generated from the real transitions. Then sign what remains. The walker
prints each trial's binding constraint, with its evidence, above the signing command.

## 3. Corrections and findings, including against my own work"""
assert old in s
s = s.replace(old, new)
s = s.replace("- **Codex calls, 2 in total, logged in `nr-2026-09-25/CALL_LOG.jsonl`:** NR-C00 was the liveness probe (\"OK,\n  GPT-6\"), and NR-C01 was the bulk comparison.",
              "- **Codex calls, 3 in total, logged in `nr-2026-09-25/CALL_LOG.jsonl`:** NR-C00 was the liveness probe (\"OK,\n  GPT-6\"), NR-C01 was the bulk comparison, and NR-C02 hit the usage limit (rc=1, no answer used). The seat is\n  exhausted until 26 Sep 18:09.")
assert "NR-C02 hit the usage limit" in s
h.write_bytes(s.encode("utf-8"))

m = Path(r"C:/mh-lanes/nr/work/make_report.py")
t = m.read_text(encoding="utf-8")
old = '''        f"   - how_it_reached_the_reviewer: {r['how_it_reached_the_reviewer']}\\n"'''
new = '''        f"   - departures the admission check misread (lane, B2): {r['departures_misread_by_check']} of {r['departures']}"
        + (" -- EVERY departure; the lane recommends fixing the check before signing\\n"
           if r['departures'] and r['departures_misread_by_check'] == r['departures'] else "\\n")
        + f"   - how_it_reached_the_reviewer: {r['how_it_reached_the_reviewer']}\\n"'''
assert old in t
t = t.replace(old, new)
m.write_bytes(t.encode("utf-8"))
print("ok")
