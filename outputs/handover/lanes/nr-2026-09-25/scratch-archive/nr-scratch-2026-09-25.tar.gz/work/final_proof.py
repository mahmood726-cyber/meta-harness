from pathlib import Path
import subprocess

text = Path(r"C:/mh-lanes/nr/work/REPORT_head.md").read_text(encoding="utf-8")
subprocess.run(["python", r"C:/mh-lanes/nr/work/make_report.py"], check=True, cwd=r"C:/mh-lanes/nr/wt",
               env={**__import__("os").environ, "PYTHONUTF8": "1"})
proof = """
## Final landing proof (tip `163148bd`, before this report-only commit)
A fresh clone of `origin/nr/notice-anchors` was made at `C:\\mh-lanes\\nr\\land`:
- 8 of 8 files changed since `1fa77f2c` under `scripts/`, `tests/` and `registry/` are byte-identical to the local
  commit, both in `git show` of the fetched commit and as checked out.
- 66 of 66 targeted tests pass there, with `--basetemp` on C:.
- `python scripts/sign_walk.py --notice N25` presents judgement B2-N25 with 8 of 8 commit-pinned anchors verified,
  and prints "4 of 4 departures fail the admission check because of how the check reads rows the site already
  holds" above the command.
This commit adds only this report text, and no code. Nothing was signed at any point.
"""
for dest in (Path(r"C:/mh-lanes/nr/REPORT_2026-09-25.md"),
             Path(r"C:/mh-lanes/nr/wt/outputs/handover/lanes/nr-2026-09-25/REPORT_2026-09-25.md")):
    body = dest.read_text(encoding="utf-8")
    marker = "\n## Signing list for Mahmood"
    body = body.replace(marker, proof + marker, 1)
    dest.write_bytes(body.encode("utf-8"))
print("ok")
