from pathlib import Path

p = Path(r"C:/mh-lanes/nr/work/HANDOVER_MAIN_LANE_P5_FIX.md")
s = p.read_text(encoding="utf-8")
s = s.replace("(85 with code only, 94 with\nD3)", "(85 with code only, 93 with\nD3)")
s = s.replace("| The repo's own `trial_family` / admission tests, original against patched | see `p5-fix/tests_*.log` (summary in §5) |",
              "| The repo's own tests (7 files: trial_family, _contract, _ui, publication_unit, admission_routes, "
              "admission_enforced, known_missing_panel), original against patched | original: 15 failed, 58 passed. "
              "Patched: 14 failed, 59 passed. **0 new failures.** All 14 are the same missing-file errors the "
              "sparse clone causes on the original (`cache/`, `docs/*.json` not checked out). The 15th, a "
              "live-browser UI test, failed only on the original run (`p5-fix/tf_tests_*.log`) |")
s = s.replace("| Every readmitted departing trial fails admission on P5 alone, or on P5 plus P8 with an `unbound_legacy` "
              "binding | all readmitted trials qualify, so all are pooled (`admission.py:100`, MIGRATION_STATE) |",
              "| Every readmitted departing trial fails admission on P5 alone, or on P5 plus P8 with an `unbound_legacy` "
              "binding | all readmitted trials qualify: 9 are P5+P8, all 9 `unbound_legacy`. All are pooled "
              "(`admission.py:100`, MIGRATION_STATE) |\n"
              "| The patch applies to `harness/trial_family.py` at `1fa77f2c` | `git apply` is clean and reproduces the "
              "tested module byte-for-byte (with `core.autocrlf=false`) |\n"
              "| Every sign command on Mahmood's list, replayed as printed (test signer, temporary ledger copy) | 19 of 19 "
              "write a signature the gate's `signature_problem` accepts, bound to the named judgement and hash; the "
              "repository ledger is unchanged |")
assert "93 with" in s and "0 new failures" in s and "19 of 19" in s, "edits"
p.write_bytes(s.encode("utf-8"))
print("ok")
