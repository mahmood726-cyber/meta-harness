from pathlib import Path
import re

p = Path(r"C:/mh-lanes/nr/wt/outputs/handover/lanes/NR_DECISIONS.md")
s = p.read_text(encoding="utf-8")
s = re.sub(r"\(dropped into `C:.*?at 08:20, read as data\)",
           "(dropped into this lane's local working directory at 08:20, read as data)", s, flags=re.S)
s = re.sub(r"\(`C:.{0,40}?B\.patch`, sha256 1dc05db7…\)", "(`B.patch`, sha256 1dc05db7…, held locally by F4)", s,
           flags=re.S)
s = s.replace("\x08", "")
p.write_bytes(s.encode("utf-8"))
print([l for l in s.splitlines() if "08:20" in l or "B.patch" in l])
print("control chars:", [hex(ord(c)) for c in s if ord(c) < 32 and c not in "\n"])
