from pathlib import Path

W = Path(r"C:/mh-lanes/nr/wt")
p = W / "tests/test_notice_anchor.py"
s = p.read_text(encoding="utf-8")

start = s.index("def test_a_rebuilt_page_detaches_and_the_walker_refuses_naming_the_judged_version")
end = s.index("def test_refreshing_the_top_level_digests_without_a_judgement_refuses")
s = s[:start] + '''def _page(row):
    return ROOT / row["page_evidence"]["html_path"]


def test_a_rebuild_that_only_churns_the_page_no_longer_detaches_and_is_disclosed(loaded, monkeypatch, capsys):
    # The positive control Decision B exists for: a rebuild re-renders the page (here: extra bytes at the end), the
    # notice's block, result and membership are untouched -> the walk presents, and SAYS the page was rebuilt.
    row = next(r for r in loaded[0]["notices"] if r["audit_id"] == "N20")
    _mutate_bytes(monkeypatch, _page(row), _page(row).read_bytes() + b"<!-- rebuilt -->")
    assert walk.main(["--notice", "N20"]) == 0
    out = capsys.readouterr().out
    assert "Rebuilt since judgement (disclosed" in out and row["page_evidence"]["html_path"] in out
    assert "python scripts/countersign_result_change.py sign" in out


def test_a_rebuilt_page_without_the_judged_block_is_stale_and_refuses(loaded, monkeypatch, capsys):
    row = next(r for r in loaded[0]["notices"] if r["audit_id"] == "N20")
    _mutate_bytes(monkeypatch, _page(row), b"<html>rebuilt page carrying no notice block</html>")
    assert walk.main(["--notice", "N20"]) == 1
    err = capsys.readouterr()
    assert not err.out
    assert "STALE" in err.err and "no longer carries the rendered block" in err.err
    assert "no signing command offered" in err.err


def test_a_page_that_now_serves_a_different_after_is_stale_for_every_walk(loaded, monkeypatch, capsys):
    row = next(r for r in loaded[0]["notices"] if r["audit_id"] == "N28")
    review_path = ROOT / row["page_evidence"]["review_path"]
    review = json.loads(review_path.read_bytes())
    for outcome in review["outcomes"]:
        if outcome["name"] == row["outcome"]:
            outcome["result"]["estimate"] = 0.84  # one served number moves; nothing else does
    _mutate_bytes(monkeypatch, review_path, json.dumps(review).encode("utf-8"))
    assert walk.main(["--notice", "N01"]) == 1  # another notice: the walk as a whole refuses
    err = capsys.readouterr().err
    assert "STALE" in err and "N28" in err and "not the after the notice records" in err


def test_a_changed_pooled_membership_is_stale(loaded, monkeypatch, capsys):
    row = next(r for r in loaded[0]["notices"] if r["audit_id"] == "N22")
    review_path = ROOT / row["page_evidence"]["review_path"]
    review = json.loads(review_path.read_bytes())
    for outcome in review["outcomes"]:
        if outcome["name"] == row["outcome"]:
            outcome["membership"]["pooled"] = list(reversed(outcome["membership"]["pooled"]))[:-1] + ["PMID 1"]
    _mutate_bytes(monkeypatch, review_path, json.dumps(review).encode("utf-8"))
    assert walk.main(["--notice", "N22"]) == 1
    assert "pooled membership is now" in capsys.readouterr().err


def test_the_discriminating_probe_a_corrupted_pinned_digest_is_detached(loaded, monkeypatch, capsys):
    # A walk that ignored the anchors would pass the churn control above; this one proves the pinned bytes are read.
    audit = copy.deepcopy(loaded[0])
    anchor_ = audit["notices"][0]["judgements"][-1]["anchors"][2]
    anchor_["sha256"] = "0" * 64
    audit["source_digests"][anchor_["ref"]] = "0" * 64
    original = Path.read_text
    monkeypatch.setattr(Path, "read_text", lambda p, *a, **k: json.dumps(audit) if p == walk.AUDIT else original(p, *a, **k))
    assert walk.main(["--notice", "N20"]) == 1
    assert "DETACHED" in capsys.readouterr().err


''' + s[end:]

old_start = s.index("def test_sign_refuses_a_detached_anchor_even_with_the_right_digest")
old_end = s.index("@pytest.mark.parametrize(\"digest,judgement\"")
s = s[:old_start] + '''def test_sign_refuses_a_stale_notice_even_with_the_right_digest(loaded, monkeypatch):
    audit, notices, _, mapping = loaded
    row = next(r for r in audit["notices"] if r["audit_id"] == "N20")
    index = mapping["N20"]
    sha = cli._block_and_sha(notices[index])[2]
    _forbid_writes(monkeypatch)
    _mutate_bytes(monkeypatch, _page(row), b"<html>rebuilt page carrying no notice block</html>")
    with pytest.raises(SystemExit, match="STALE"):
        cli.main(_sign_args(row, index, sha, anchor.current_judgement(row)["judgement_id"]))


''' + s[old_end:]
p.write_bytes(s.encode("utf-8"))

p = W / "tests/test_sign_walk.py"
s = p.read_text(encoding="utf-8")
s = s.replace('''    assert not output.out and "DETACHED" in output.err  # decision B: a changed page detaches its judged anchor''',
              '''    assert not output.out and "STALE" in output.err  # decision B: a page that no longer serves the judged result''')
old = '''    audit = {"notices": [row], "decision_groups": []}
    chains = [{"slug": notice["slug"], "outcome": notice["outcome"], "indices": [0], "ok": True, "problems": []}]
    output = walk.present(audit, [notice], chains, {"TEST": 0}, 1)'''
new = '''    audit = {"notices": [row], "decision_groups": []}
    chains = [{"slug": notice["slug"], "outcome": notice["outcome"], "indices": [0], "ok": True, "problems": []}]
    # Fictional notice: no page exists, so the decision-B guard is replaced by a fictional judgement in RAM only.
    judgement = {"judgement_id": "TEST-J", "judged_utc": "2000-01-01T00:00:00Z", "served_commit": "0" * 40,
                 "proposed_commit": "0" * 40, "anchors": [], "before_after": "synthetic", "defects": []}
    monkeypatch.setattr(walk.notice_anchor, "guard", lambda *a, **k: (judgement, []))
    output = walk.present(audit, [notice], chains, {"TEST": 0}, 1)'''
assert old in s
s = s.replace(old, new)
s = s.replace("def test_already_signed_synthetic_notice_offers_no_signing_command():",
              "def test_already_signed_synthetic_notice_offers_no_signing_command(monkeypatch):")
p.write_bytes(s.encode("utf-8"))
print("ok")
