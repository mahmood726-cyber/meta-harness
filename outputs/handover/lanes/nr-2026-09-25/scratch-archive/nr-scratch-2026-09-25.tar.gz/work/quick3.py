import json,subprocess,sys
sys.path.insert(0,r'C:/mh-lanes/nr/wt')
from harness.result_changes import result_tuple,_same
R=r'C:/mh-lanes/nr/repo'
def show(ref,p):
    r=subprocess.run(['git','-C',R,'show',f'{ref}:{p}'],capture_output=True); return r.stdout if r.returncode==0 else None
led=json.loads(show('origin/enforcement-gate','docs/result_changes.json'))['notices']
op=[(i,n) for i,n in enumerate(led) if (n.get('reviewer_countersignature') or {}).get('state','OPEN')=='OPEN']
cache={}
def outc(ref,slug,name):
    k=(ref,slug)
    if k not in cache:
        b=show(ref,f'docs/reviews/{slug}/review.json'); cache[k]=json.loads(b) if b else None
    r=cache[k]
    if r is None: return 'NOPAGE'
    m=[o for o in r['outcomes'] if o['name']==name]
    return result_tuple(m[0].get('result')) if len(m)==1 else f'NOOUTCOME({len(m)})'
rows=[]
for i,n in op:
    b0=outc('38c04411',n['slug'],n['outcome']); s=outc('origin/main',n['slug'],n['outcome']); e=outc('origin/enforcement-gate',n['slug'],n['outcome'])
    f=lambda x,y: 'ok' if isinstance(x,dict) and _same(x,y) else 'DIFF'
    rows.append((i,n['slug'][:28],n['outcome'][:30],f(b0,n['before']),f(s,n['before']),f(e,n['after'])))
    if f(s,n['before'])!='ok': print('  served-now',i,n['slug'],n['outcome'],'before',n['before'],'served',s)
for r in rows: print(*r)
print(len(op))
