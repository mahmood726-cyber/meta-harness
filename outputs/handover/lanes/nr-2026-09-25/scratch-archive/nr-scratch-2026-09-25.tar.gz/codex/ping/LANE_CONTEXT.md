# LANE_CONTEXT -- read this first

This directory is the scratch working directory of recorded model calls for the meta-harness `nr` lane (notice re-judgement)
(reproducible_ai/model_call_live.py). It holds nothing you need.

Your task is ONLY the prompt you were given. Everything you need is inside that prompt text.

Nothing outside this prompt is context: do not read, list or search any other file or directory on this machine
(no AGENTS.md, CLAUDE.md, INDEX.md, workbooks, registries, other repositories, home directories). Do not run commands.
Do not write anything. Answer from the prompt text alone, in the JSON shape it asks for.
