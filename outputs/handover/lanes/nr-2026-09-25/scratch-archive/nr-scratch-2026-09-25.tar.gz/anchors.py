import json,subprocess,hashlib,sys
d=json.load(open(r'C:/mh-lanes/nr/na.json'))
def blob(ref,path):
    r=subprocess.run(['git','show',f'{ref}:{path}'],capture_output=True)
    return r.stdout if r.returncode==0 else None
for ref in sys.argv[1:]:
    ok=bad=miss=0; badl=[]
    for k,v in d['source_digests'].items():
        if k.startswith('git:'):
            _,sha,p=k.split(':',2); b=blob(sha,p)
        else:
            b=blob(ref,k)
        if b is None: miss+=1; badl.append('MISSING '+k); continue
        if hashlib.sha256(b).hexdigest()==v: ok+=1
        else: bad+=1; badl.append(k)
    print(ref,'ok',ok,'broken',bad,'missing',miss)
    print('  wt broken by kind:', {s:sum(1 for x in badl if x.endswith(s)) for s in ('review.json','index.html','.py','records.json')})
